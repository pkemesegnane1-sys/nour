# Manuel complet JavaScript / PHP / Java — source LaTeX

## Sur Overleaf (le plus simple)
1. `Nouveau projet` → `Envoyer depuis votre ordinateur` → choisir **ce ZIP**.
2. Menu ⚙️ (Settings) :
   - **Compiler** : `pdfLaTeX`
   - **Auto-compile** : `off`
   - `Main document` : `main.tex`
3. Bouton **Recompile**. Laisse latexmk faire les 2 à 3 passages (sommaire + renvois + index).
4. En cas d'erreur : `Logs and output files` → `Raw logs` → `Ctrl+F` sur `!`.

Aucune option a cocher, aucun paquet a installer : tout est dans TeX Live complet (donc sur Overleaf).

## En local
```
latexmk -pdf -interaction=nonstopmode main.tex      # ou : pdflatex x3 + makeindex + pdflatex x1
```
Paquets utilises : `fontenc inputenc babel(geometry) microtype libertine inconsolata amsmath amssymb
xcolor(+table) hyperref cleveref graphicx booktabs longtable array enumitem multicol menukeys
titletoc makeidx listings tcolorbox(+most) textcomp`.
Sous Debian/Ubuntu : `sudo apt install texlive-latex-extra texlive-fonts-extra texlive-lang-french latexmk`
Sous TeX Live : `tlmgr install libertine inconsolata titletoc menu` (le reste est deja la).

## Contenu
- `main.tex` : preambule + page de titre + `\input` des 43 chapitres. **Un seul fichier contient
  `\documentclass`**, donc Overleaf ne peut pas se tromper de document principal.
- `src/000-comment-utiliser.tex` … `src/601-antisecche.tex` : les chapitres.

## Conventions du preambule (utile si tu ajoutes du contenu)
- Blocs de code : `codejs`, `codephp`, `codejava`, `codesql`, `codeconf`, `codejson`, `codeyml`,
  `codeplain`, `terminal` = vrais environnements `listings` (verbatim) : on peut y ecrire `$ # _ % &`
  sans echapper. Ils ne peuvent **pas** etre places dans une cellule de tableau.
- Tableaux : `\begin{tabz}{lXX} … \end{tabz}` ou `\begin{tablez}[p{0.2\textwidth}X] … \end{tablez}`
  (longtable, lignes alternees, en-tete avec `\headrow \thd{...}`).
- Encadrés : `objectif`, `note`, `astuce`, `piege`, `exercice`, `ressources`, `projet`.
- Macros : `\cmd{…}` commande, `\fichier{…}` chemin, `\src{…}` lien source, `\keys{…}` raccourcis,
  `\etape{…}` etape numerotee.
